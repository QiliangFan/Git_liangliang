create
    definer = root@localhost procedure sp_set_firewall_mode(IN arg_userhost varchar(80), IN arg_mode varchar(12))
BEGIN
DECLARE result VARCHAR(80);
IF arg_mode = "RECORDING" THEN
  SELECT read_firewall_whitelist(arg_userhost,FW.rule) FROM mysql.firewall_whitelist FW WHERE userhost = arg_userhost;
END IF;
SELECT set_firewall_mode(arg_userhost, arg_mode) INTO result;
IF arg_mode = "RESET" THEN
  SET arg_mode = "OFF";
END IF;
IF result = "OK" THEN
  INSERT IGNORE INTO mysql.firewall_users VALUES (arg_userhost, arg_mode);
  UPDATE mysql.firewall_users SET mode=arg_mode WHERE userhost = arg_userhost;
ELSE
  SELECT result;
END IF;
IF arg_mode = "PROTECTING" OR arg_mode = "OFF" OR arg_mode = "DETECTING" THEN
  DELETE FROM mysql.firewall_whitelist WHERE USERHOST = arg_userhost;
  INSERT INTO mysql.firewall_whitelist SELECT USERHOST,RULE FROM INFORMATION_SCHEMA.mysql_firewall_whitelist WHERE USERHOST=arg_userhost;
END IF;
END;

