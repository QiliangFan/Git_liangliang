create definer = test@`%` trigger update_trigger_instructor3
    after UPDATE
    on instructor3
    for each row
begin
        if (OLD.name is null and NEW.name is not null) or (OLD.name is not null and new.name is not null and OLD.name!=new.name) then
        insert into mylog3(instruct_id,tbname,colname,event,oldvalue,newvalue,date)
            values ( NEW.ID,'instructor3','name','update',OLD.name, NEW.name,curtime());
        end if;
        if (OLD.dept_name is null and NEW.dept_name is not null) or (OLD.dept_name is not null and new.dept_name is not null and OLD.dept_name!=new.dept_name) then
        insert into mylog3(instruct_id, tbname, colname, event, oldvalue,newvalue,date)
            values (NEW.ID,'instructor3','dept_name','update',OLD.dept_name,NEW.dept_name,curtime());
        end if;
        if (OLD.salary is null and NEW.salary is not null) or (OLD.salary is not null and new.salary is not null and OLD.salary!=new.salary) then
        insert into mylog3(instruct_id, tbname, colname, event, oldvalue,newvalue,date)
            values (NEW.ID,'instructor3','salary','update',old.salary,NEW.salary,curtime());
        end if;
    end;

