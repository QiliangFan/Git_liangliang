create definer = test@`%` trigger insert_trigger_instructor3
    after INSERT
    on instructor3
    for each row
begin
        insert into mylog3(instruct_id,tbname,colname,event,newvalue,date)
            values ( NEW.ID,'instructor3','name','insert', NEW.name,curtime());
        insert into mylog3(instruct_id, tbname, colname, event, newvalue,date)
            values (NEW.ID,'instructor3','dept_name','insert',NEW.dept_name,curtime());
        insert into mylog3(instruct_id, tbname, colname, event, newvalue,date)
            values (NEW.ID,'instructor3','salary','insert',NEW.salary,curtime());

    end;

