create
    definer = test@`%` function fun(c_id varchar(8)) returns int
begin 
    declare i integer default 0;

#     if exists(select * from prereq t where t.course_id=c_id) then
    insert into result
    values ((select distinct t0.prereq_id
        from prereq t0
        where t0.course_id=c_id
    ));
#     end if;
    return i; 
end;

