create definer = test@`%` trigger delete_trigger_instructor3
    after DELETE
    on instructor3
    for each row
begin
        insert into mylog3(instruct_id,tbname,colname,event,oldvalue,date)
            values ( OLD.ID,'instructor3','name','delete',OLD.name, curtime());
        insert into mylog3(instruct_id, tbname, colname, event, oldvalue,date)
            values (old.ID,'instructor3','dept_name','delete',OLD.dept_name,curtime());
        insert into mylog3(instruct_id, tbname, colname, event, oldvalue,date)
            values (old.ID,'instructor3','salary','delete',old.salary,curtime());
    end;

