create
    definer = test@`%` function f() returns int
return 1;

