create
    definer = root@localhost procedure sp_reload_firewall_rules(IN arg_userhost varchar(80))
BEGIN
  SELECT set_firewall_mode(arg_userhost, "RESET") AS 'Result';
  SELECT read_firewall_whitelist(arg_userhost,FW.rule) AS 'Result' FROM mysql.firewall_whitelist FW WHERE FW.userhost=arg_userhost;
END;

